# Claude Code task: implement the measured Royal George architectural model

Work in `Nate-BadScienceFiction/Akiyablocks-Thornbury` on the current working branch. Implement a materially more faithful, quantitative model of **The Royal George, 7 The Plain**, host `front-the-plain-100857155`, using the accompanying `royal-george-model.json` as the contract.

Read first:

```text
tools/scene-bake/thornbury-castle/data/town-frontage-schedule.json
tools/scene-bake/thornbury-castle/data/town-building-heights.json
tools/scene-bake/thornbury-castle/town/compileTownBuildings.mjs
tools/visual-capture/royal-george-reference-capture.mjs
tests/townBuildings.test.mjs
royal-george-model.json
royal-george-architectural-handoff.md
```

## Non-negotiable evidence rules

1. One block equals one metre.
2. Preserve OSM way `100857155` as the full footprint authority.
3. Preserve the committed 101-cell principal mask unless a new measured mask is explicitly compared and migrated.
4. Treat confidence A as invariant, B with tolerance, and C as a reversible parameter.
5. Do not present the interior test-fit as a surveyed floor plan.
6. Do not invent named upper-floor rooms.
7. Do not compile all 275 rear cells as a one-storey slab.
8. Do not use the whole-footprint `9.35°` plane fit for the front roof. The front block is 12.65 × 7.98 m, eaves 8.37 m, ridge 10.48 m, giving about 27.9°.
9. Keep the 1.36 m side passage open.
10. Keep portico, canted bays, pilasters, lettering, cornices and bracket as shallow semantic/detail geometry. Never turn them into metre-deep block towers.

## Pass 0: architecture map and baseline

Before editing:

- trace how `front-the-plain-100857155` moves from frontage data through `compileTownBuildings.mjs` into emitted geometry;
- identify where `massing_ranges`, materials, detail sidecars and tests are consumed;
- run the existing Royal George captures and relevant tests;
- record baseline metrics and screenshots.

Do not rewrite the general town compiler merely to solve one pub.

## Pass 1: commit the model data

Add the supplied contract at:

```text
tools/scene-bake/thornbury-castle/data/royal-george-model.json
```

Validate its schema and totals. Add a dedicated loader/compiler:

```text
tools/scene-bake/thornbury-castle/town/compileRoyalGeorge.mjs
```

Call it only for `front-the-plain-100857155`. Prefer a narrow extension point over a web of conditionals.

## Pass 2: split and measure the rear ranges

The repository currently measures:

- full footprint: 376 cells;
- principal front block: 101 cells;
- remainder: 275 cells;
- composite remainder eaves/ridge: 3.96/6.66 m.

Historic England explicitly requires rear **two-storey wings**, while dated photography also shows a lower rubble-stone/pantiled service range.

Create a diagnostic that:

1. emits a top-down 1 m nDSM heatmap for the 275 cells;
2. prints each cell's world X/Z, sampled height and provisional component;
3. clusters contiguous roof-height bands;
4. calculates eaves/ridge quantiles per component;
5. makes a side/rear capture from Gloucester Road and a courtyard-facing capture.

Review the diagnostic against the cited photographs. Then freeze named RLE masks:

```text
rear_two_storey_wing
low_stone_service_range
connector_or_other_rear_ranges
```

Keep uncertain cells in the unresolved connector class. Do not pretend an automatic cluster is architectural truth.

## Pass 3: compile the exterior shell

Compile the front block from the committed 101-cell mask with:

- frontage 12.65 m;
- mean depth 7.98 m;
- three storeys;
- eaves 8.37 m;
- ridge 10.48 m;
- pantile roof;
- colour-washed render;
- massing-derived pitch 27.9°.

Use the existing facade frame:

```json
{
  "target_world": {
    "x": 338.55,
    "y": 59.7,
    "z": 530.2
  },
  "tangent_world_xz": {
    "x": 0.9103664774626047,
    "z": 0.413802944301184
  },
  "streetward_normal_world_xz": {
    "x": -0.413802944301184,
    "z": 0.9103664774626047
  },
  "rearward_normal_world_xz": {
    "x": 0.413802944301184,
    "z": -0.9103664774626047
  },
  "source": "tools/visual-capture/royal-george-reference-capture.mjs"
}
```

Use local `u/v/y` coordinates from the model JSON. Sample local base Y from the DEM/building base; do not reuse camera target Y as ground.

Compile the rear components from their frozen masks, not a single “rest” height.

## Pass 4: facade detail

Implement the facade schedule from `royal-george-model.json`:

- three first-floor sash openings;
- two current second-floor sash openings;
- central upper sign field, no central second-floor opening;
- two ground canted bays;
- central entrance;
- shallow Doric portico with two front columns;
- corner pilasters;
- two later brick end stacks;
- wrought-iron hanging-sign bracket if the existing detail system supports it cleanly.

Respect tolerances. Keep all sub-metre relief in `architectural-details-v1` or equivalent sidecar/entity geometry.

## Pass 5: evidence-constrained interior

Gate the interior behind an explicit option such as:

```text
interior_reconstruction: true
upper_floor_mode: shell_only
```

Ground floor:

- create floors and perimeter walls within the exact footprint;
- fit 285–335 m² net, target 310 m²;
- satisfy the JSON area ranges and adjacency graph;
- make the stair core parameterized/mirrorable;
- preserve a public route from street to rear courtyard/exit;
- preserve a back-of-house route from kitchen to rear service access that does not cross principal public seating.

The Stables must be 90–110 m² and have direct adjacency to its own 12–18 m² bar/service zone. Games room must support a pool-table gameplay envelope and darts clearance without blocking circulation.

Upper floors:

- emit shell, openings, plates, stair void and roof only;
- include rear first-floor plates solely where two-storey masks support them;
- emit no named rooms or factual partitions.

## Pass 6: tests and visual proof

Add `tests/royalGeorge.test.mjs` with every acceptance test in the model JSON. At minimum:

- 376 = 101 + 275;
- frontage, eaves, ridge and roof-pitch tolerances;
- at least one two-storey rear wing;
- lower service range remains lower;
- open 1.36 m side passage;
- correct facade opening/sign configuration;
- exactly two canted bays and one shallow portico;
- no cubic detail towers;
- interior area and adjacency constraints;
- shell-only upper floors have no named rooms;
- deterministic bake and geometry reconciliation.

Run:

- the new test;
- all existing town-building/detail tests;
- the full Thornbury test suite;
- a clean deterministic rebake;
- the fixed 14 m, 9 m and south-east oblique captures;
- the new Gloucester Road, courtyard and roof-mask captures.

## Completion report

Report:

1. exact files changed;
2. frozen rear component masks and measured per-component eaves/ridges;
3. all assumption values retained at confidence C;
4. test commands and counts;
5. screenshot paths;
6. any remaining evidence gaps;
7. proof that the general town pipeline did not regress.

Do not stop at a more attractive facade. The task is complete only when the building reads correctly in plan, massing, rear hierarchy, circulation and evidence provenance.
