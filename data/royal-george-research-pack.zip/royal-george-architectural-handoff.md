# The Royal George, Thornbury
## Quantitative architectural model and AkiyaBlocks implementation handoff

**Prepared:** 14 August 2026  
**Target:** `Nate-BadScienceFiction/Akiyablocks-Thornbury`, current `main` scene pipeline  
**Building:** The Royal George, 7 The Plain, Thornbury, NHLE 1321108, OSM way 100857155  
**Model status:** Research-backed exterior shell; evidence-constrained functional interior test-fit

> This is an implementation model, not a measured-building survey. Exterior massing is unusually strong because the repository already contains an OSM footprint, a 1 m LiDAR measurement pass, a measured frontage schedule, and a fixed facade capture frame. The public record does not expose a defensible surveyed floor plan, so interior walls remain reversible test-fit geometry.

## 1. Executive finding

The existing scene has the correct seed of the building but simplifies the rear too aggressively. The front range can now be specified as a **12.65 m × 7.98 m, three-storey block**, with eaves at **8.37 m**, ridge at **10.48 m**, and a massing-derived roof pitch of **27.9°**. The complete footprint contains **376 one-metre cells**: **101** in the front range and **275** behind it.

The important correction is at the rear. Historic England's description calls out **two-storey rear wings**. The present compiler's single “rest” statistic, eaves 3.96 m and ridge 6.66 m, mixes those wings with lower service buildings. Compiling all 275 rear cells as one low storey therefore erases the building's real hierarchy. Split the remainder into at least a two-storey rendered/pantiled wing and a lower rubble-stone/pantiled service range, then retain a named unresolved connector class for cells not yet securely assigned.

The current interior program is well supported, but its partitions are not. The official site identifies the main bar, the Stables restaurant/function room, a separate Stables bar, a games room with pool and darts, a rear courtyard/patio, and a rear car park. The function-room page advertises capacity for up to 70. These facts support a credible playable test-fit, but not a claim about exact wall or stair locations.

## 2. Confidence language

| Mark | Meaning | Modelling rule |
|---|---|---|
| **A** | Authoritative description or repository measurement tied to OSM/LiDAR | May be asserted and tested as invariant |
| **B** | Derived from A data or scaled from dated/current photography | Implement with stated tolerance |
| **C** | Typological or functional test-fit | Parameterize; keep reversible |
| **U** | Unknown | Leave shell-only or omit |

Never silently promote B or C geometry to A.

## 3. Coordinate contract

The scene uses one metre per block, with **+X east**, **+Z south**, and **+Y up**.

The existing fixed capture frame supplies:

```json
{
  "facade_target": {"x": 338.55, "y": 59.7, "z": 530.2},
  "tangent_xz": {"x": 0.9103664774626047, "z": 0.413802944301184},
  "streetward_normal_xz": {"x": -0.413802944301184, "z": 0.9103664774626047},
  "rearward_normal_xz": {"x": 0.413802944301184, "z": -0.9103664774626047}
}
```

Define local architectural coordinates:

- `u`: along the facade from its left/north-west end when facing it;
- `v`: rearward;
- `y`: above a sampled local base;
- world transform: `X = X0 + u*Tx + v*Rx`, `Z = Z0 + u*Tz + v*Rz`.

Do **not** hardcode the capture target's `y=59.7` as ground. It is a camera focus. Sample the DEM or the existing building base at each component.

### Clean principal-range envelope

| Point | World X | World Z |
|---|---:|---:|
| `frontage_s0` | 332.791932 | 527.582696 |
| `frontage_s1` | 344.308068 | 532.817304 |
| `rear_s1` | 347.611949 | 525.548765 |
| `rear_s0` | 336.095813 | 520.314158 |
| clean-envelope centroid | 340.201941 | 526.565731 |

This clean rectangle is a useful architectural frame. Preserve the committed 101-cell raster mask as the authoritative voxel footprint unless a new measured mask passes a migration test.

## 4. Exterior dimensional schedule

### 4.1 Principal front block

| Attribute | Value | Confidence |
|---|---:|---|
| frontage | **12.65 m** | A |
| raster area | **101 m²/cells** | A |
| mean depth, area ÷ frontage | **7.98 m** | B |
| storeys | **3** | A |
| eaves / wall top | **8.37 m** | A |
| ridge | **10.48 m** | A |
| roof rise | **2.11 m** | A-derived |
| roof pitch from rise/run | **27.9°** | B |
| roof | pantile | A |
| wall | colour-washed render | A |
| end stacks | later brick | A-existence |

The existing `9.35°` roof-plane number is a known low-biased single-plane fit across the mixed full footprint. It must not be reused as the pitch of the front block.

### 4.2 Facade, local `u/y` dimensions

The listing fixes the form. Dated/current photographs scale the implementation envelopes below against the measured 12.65 m frontage and 8.37 m wall height.

| Element | Quantitative envelope | Confidence |
|---|---|---|
| bay centres | `u = 2.55, 6.325, 10.10 m` | B |
| first-floor sashes | 3 × `1.10 × 1.75 m`; sill `y=3.70`; head `y=5.45` | B, ±0.15 m |
| current second-floor sashes | 2 × `1.10 × 1.10 m`; centres `u=2.55, 10.10`; sill `6.45`; head `7.55` | B, ±0.15 m |
| central upper sign field | `u=3.75..8.90`; `y=5.70..6.35`; flush to 0.08 m projection | B |
| canted ground bays | 2 × 3.10 m overall; 0.65 m projection; cornice top `3.15` | A-form/B-size |
| entrance | centre `u=6.325`; `1.20 × 2.15 m` | B |
| Doric portico | 4.55 m wide; 1.05 m projection; cornice top `3.55`; two 0.30 m columns | A-form/B-size |
| corner pilasters | 0.30 m wide; about 0.08 m projection | A-form/B-size |
| chimney shafts | about `0.75 × 0.55 m`; top about `y=12.0 m` | A-existence/C-size |

**Representation rule:** keep the portico, canted bay relief, pilasters, cornices, lettering and sign bracket in `architectural-details-v1` or equivalent sub-metre detail geometry. A one-metre voxel is a brick elephant here.

### 4.3 Rear hierarchy

The full footprint is 376 cells and the principal mask is 101, leaving 275 rear cells. Use the exact OSM footprint as the outer authority, but do not assign the remainder one height.

Required named components:

1. **`rear_two_storey_wing`**  
   Existence A; exact mask C pending extraction. Start with eaves 4.9–5.6 m and ridge 6.3–7.1 m.

2. **`low_stone_service_range`**  
   Existence B from dated Gloucester Road imagery. Start with eaves 2.7–3.3 m and ridge 4.0–4.7 m.

3. **`connector_or_other_rear_ranges`**  
   Deliberately unresolved. Do not force uncertain cells into a stronger class.

### Required extraction gate

1. Rasterize only the 275-cell remainder.
2. Export a top-down nDSM heatmap with cell values and current class.
3. Detect contiguous roof-height bands, then calculate per-band perimeter/eaves and interior/ridge quantiles.
4. Compare ordering and roof breaks with the 2022 Gloucester Road oblique and current courtyard photographs.
5. Freeze accepted component masks as RLE in `royal-george-model.json`.
6. Keep an explicit unresolved class and an audit note for every declined assignment.

This turns the current composite statistic into inspectable architecture rather than a height smoothie.

## 5. Interior model

### 5.1 What is factual

- Main public bar.
- Stables restaurant/function room.
- Stables has its own bar.
- Games room with pool and darts.
- Rear courtyard/patio and rear car park.
- Advertised Stables capacity: up to 70 people.

### 5.2 What is not established

No surveyed floor plan, exact stair location, exact kitchen/WC arrangement, cellar layout, room dimensions, or upper-floor partitions were located in the public sources reviewed. Do not label the inferred layout “actual floor plan.”

### 5.3 Ground-floor program test-fit

Use **376 m² gross** and target **310 m² net**, with an acceptable range of **285–335 m²**.

| Zone | Target | Acceptable range | Evidence status |
|---|---:|---:|---|
| Main bar / lounge | 72 m² | 65–85 | B-program/C-area |
| Stables restaurant / function room | 94 m² | 90–110 | B-program/C-area |
| Stables own bar / service | 14 m² | 12–18 | B-program/C-area |
| Games room | 30 m² | 25–40 | B-program/C-area |
| Commercial kitchen | 36 m² | 30–45 | C |
| Public WCs | 20 m² | 18–28 | C |
| Entrances, circulation, stair | 23 m² | 18–32 | C |
| Store, staff, cellar access | 21 m² | 18–32 | C |
| **Total** | **310 m²** | **285–335 net envelope** | test-fit |

### 5.4 Adjacency contract

```text
street entrance -> main bar
main bar -> games room
main bar -> Stables
main bar -> public WCs
main bar -> provisional stair core
Stables -> its own bar
Stables -> kitchen/service
Stables -> courtyard/rear exit
kitchen -> service yard/rear car park
courtyard -> rear car park
```

The kitchen/service route must not require walking through principal public seating. The stair envelope should remain a mirrorable parameter, provisionally 2.0 × 4.0 m with a 1.0 m clear stair width and a 3.10 m rise.

### 5.5 Upper floors

The principal front block supplies about **101 m² gross per plate**. Add first-floor rear-wing plates only where the extracted two-storey masks support them. Default to `shell_only`:

- external walls;
- floor plate;
- measured windows;
- roof/ceiling;
- stair void or provisional landing.

Do not invent bedrooms, offices or factual corridors.

## 6. Repository implementation

Add:

```text
tools/scene-bake/thornbury-castle/data/royal-george-model.json
tools/scene-bake/thornbury-castle/town/compileRoyalGeorge.mjs
tests/royalGeorge.test.mjs
```

Integrate the special compiler from `compileTownBuildings.mjs` when the host is `front-the-plain-100857155`.

Implementation order:

1. Read and validate the JSON model.
2. Preserve the exact full OSM footprint and committed 101-cell principal mask.
3. Run the rear-mask extraction gate and commit named RLE masks.
4. Compile principal and rear components with distinct eaves/ridges.
5. Compile facade openings and semantic details from the local `u/v/y` frame.
6. Add ground-floor floors/walls only behind `interior_reconstruction`.
7. Keep upper floors shell-only by default.
8. Add structural, circulation, provenance and screenshot tests.
9. Re-run the whole Thornbury bake and regression suite.

## 7. Acceptance tests

The implementation is complete only when all of these pass:

- Full footprint = 376 cells; principal = 101; remainder = 275.
- Frontage = 12.65 ±0.15 m.
- Principal eaves = 8.37 ±0.25 m; ridge = 10.48 ±0.25 m.
- Principal roof pitch is 26–30°, never the 9.35° composite fit.
- At least one rear two-storey wing mask exists.
- The low stone range is lower than the rear wing.
- The 1.36 m side passage remains open and traversable.
- Current central upper sign field exists; no central second-floor window is emitted.
- Exactly two canted ground bays and one shallow Doric portico are emitted.
- Detail geometry does not become cubic-metre towers or an arcade.
- Interior program total = 310 m²; accepted net layout = 285–335 m².
- Stables = 90–110 m² and directly adjoins its own bar.
- Public route connects the street entrance to the rear courtyard/exit.
- Service route connects kitchen to rear service access without crossing main seating.
- `shell_only` emits no named upper rooms.
- Existing front captures pass, plus new Gloucester Road, courtyard and roof-mask diagnostic captures.

## 8. Deliverables in this pack

- `royal-george-model.json`: machine-readable geometry, confidence, program and tests.
- `royal-george-elevation.svg`: scaled facade/elevation schedule.
- `royal-george-plan.svg`: shell geometry and area-based interior test-fit diagram.
- `royal-george-claude-code-prompt.md`: direct implementation brief.
- This document.

## 9. Source register

- Historic England, list entry 1321108: <https://historicengland.org.uk/listing/the-list/list-entry/1321108>
- British Listed Buildings transcription and dated photographs: <https://britishlistedbuildings.co.uk/101321108-royal-george-inn-thornbury>
- Official Royal George site: <https://www.theroyalgeorgethornbury.co.uk/>
- Official venue-hire page: <https://www.theroyalgeorgethornbury.co.uk/venue-hire>
- Official gallery: <https://www.theroyalgeorgethornbury.co.uk/gallery>
- Thornbury Roots local history: <https://www.thornburyroots.co.uk/pubs/royal-george/>
- OSM way 100857155: <https://www.openstreetmap.org/way/100857155>
- Repository frontage schedule: `tools/scene-bake/thornbury-castle/data/town-frontage-schedule.json`
- Repository LiDAR heights: `tools/scene-bake/thornbury-castle/data/town-building-heights.json`
- Repository fixed capture: `tools/visual-capture/royal-george-reference-capture.mjs`
