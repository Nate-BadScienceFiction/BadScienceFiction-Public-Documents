Royal George quantitative research pack
=======================================

Files
-----
- royal-george-architectural-handoff.md
  Detailed evidence, dimensions, uncertainty rules, interior test-fit, repository plan and acceptance tests.

- royal-george-model.json
  Machine-readable geometry and implementation contract. Intended to be copied into:
  tools/scene-bake/thornbury-castle/data/royal-george-model.json

- royal-george-claude-code-prompt.md
  Direct build brief for Claude Code.

- royal-george-elevation.svg
  Scaled facade implementation diagram.

- royal-george-plan.svg
  Principal-shell and area/adjacency diagram. The rear shape and interior partitions are deliberately labelled non-surveyed.

Important
---------
This pack is suitable for game-scene implementation and evidence-aware refinement.
It is not a measured-building, cadastral, construction, access, fire-safety or regulatory survey.
